package com.campus.management.model;

public enum EventStatus {
    PENDING,
    APPROVED,
    REJECTED
}
