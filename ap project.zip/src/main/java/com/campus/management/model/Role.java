package com.campus.management.model;

public enum Role {
    ADMIN,
    ORGANIZER,
    STUDENT
}